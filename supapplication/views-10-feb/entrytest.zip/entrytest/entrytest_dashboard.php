<div class="main-content">
    <div class="breadcrumbs" id="breadcrumbs">
      
        <div class="nav-search" id="nav-search">
            <form class="form-search" />
            <span class="input-icon">
                <input type="text" placeholder="Search ..." class="input-small nav-search-input" id="nav-search-input" autocomplete="off" />
                <i class="icon-search nav-search-icon"></i>
            </span>
            </form>
        </div><!--#nav-search-->
    </div>

    <div class="page-content">
        <img src="<?php echo base_url();?>assets/images/entry_test.jpg" width="1098" height="1098"/>
    </div><!--/.page-content-->
    